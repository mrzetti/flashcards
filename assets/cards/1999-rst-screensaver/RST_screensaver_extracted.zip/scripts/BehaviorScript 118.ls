on exitFrame
  resetPuppets()
end
