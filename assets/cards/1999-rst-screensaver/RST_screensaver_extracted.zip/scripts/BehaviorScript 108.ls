on exitFrame
  startTimer()
end
